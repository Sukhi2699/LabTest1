import java.awt.*;
public class Invaderfactory {
	public static Invader createInvader(Invader image){
		Invader newInvader = image;
		return newInvader;
	}
	
	public Invader getInvader(Invader newInvader){
		return  newInvader;
	}
	
	 
	

}
